from django.apps import AppConfig


class TravellerConfig(AppConfig):
    name = 'traveller'
